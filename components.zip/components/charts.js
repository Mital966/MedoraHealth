function renderPie(summary){
  Highcharts.chart('pie-total', {
    chart: { type:'pie', backgroundColor:'transparent' },
    title: { text: 'Population COVID Status' },
    tooltip: { pointFormat: '{series.name}: <b>{point.y}</b> ({point.percentage:.1f}%)' },
    accessibility: { point: { valueSuffix: '%' } },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        dataLabels: { enabled: true, format: '<b>{point.name}</b>: {point.y}' }
      }
    },

    series: [{
    name: 'Count',
    data: [
      ['Affected', summary.affected],
      ['Cured', summary.cured],
      ['Not Affected', summary.notAffected],
      ['Death', summary.death]
      ]
    }]
  });
}


function renderDeathsByState(entries) {
  // entries = [ [state, count], ... ]
  Highcharts.chart('chart-deaths-state', {
    chart: { type: 'column', backgroundColor: 'transparent' },
    title: { text: null },
    xAxis: {
      categories: entries.map(e => e[0]),
      title: { text: null },
      labels: { style: { color: '#0a111f' } }
    },
    yAxis: {
      min: 0,
      title: { text: 'Deaths' },
      allowDecimals: false,
      gridLineColor: 'rgba(0,0,0,0.08)',
      labels: { style: { color: '#0a111f' } }
    },
    legend: { enabled: false },
    tooltip: {
      pointFormat: '<b>{point.y}</b> death(s)'
    },
    series: [{
      name: 'Deaths',
      data: entries.map(e => e[1])
    }],
    plotOptions: {
      column: {
        borderRadius: 3,
        pointPadding: 0.1,
        groupPadding: 0.12
      }
    },
    credits: { enabled: false }
  });
}

function renderIndiaMap(stateCounts) {
  fetch('assets/maps/in-all.geo.json')
    .then(r => r.json())
    .then(mapData => {
      const data = Object.entries(stateCounts).map(([state, value]) => ({
        name: state,
        value
      }));

      Highcharts.mapChart('india-map', {
        chart: { map: mapData, backgroundColor: 'transparent' },
        title: { text: 'Affected by State' },
        mapNavigation: { enabled: true, enableButtons: false },
        colorAxis: {
          min: 0,
          stops: [
            [0, '#1B5E20'],   // green low
            [0.5, '#FFC107'], // yellow mid
            [1, '#B71C1C']    // red high
          ]
        },
        series: [{
          data,
          name: 'Affected',
          states: { hover: { color: '#BADA55' } },
          dataLabels: { enabled: false },
          joinBy: 'name'
        }]
      });
    })
    .catch(err => {
      console.error('Map load error:', err);
      document.getElementById('india-map').innerHTML =
        '<div class="text-danger p-3">⚠️ Unable to load India map.</div>';
    });
}


function renderAgeChart(buckets){
  Highcharts.chart('age-chart', {
    chart: { type:'column', backgroundColor:'transparent' },
    title: { text: 'Age Distribution' },
    xAxis: { categories: Object.keys(buckets) },
    yAxis: { title: { text: 'Patients' } },
    series: [{ name:'Count', data:Object.values(buckets) }]
  });
}
