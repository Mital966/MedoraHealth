// function computeSummary(){
//   const patients = getPatients();
//   const summary = { affected:0, notAffected:0, death:0 };
//   const stateCounts = {};
//   const ageBuckets = { '0-17':0, '18-35':0, '36-55':0, '56+':0 };

//   patients.forEach(p => {
//     if(p.status==='Affected') summary.affected++;
//     else if(p.status==='Death') summary.death++;
//     else summary.notAffected++;

//     if(p.status==='Affected'){
//       stateCounts[p.state] = (stateCounts[p.state] || 0) + 1;
//     }
//     const age = Number(p.age)||0;
//     if(age<=17) ageBuckets['0-17']++;
//     else if(age<=35) ageBuckets['18-35']++;
//     else if(age<=55) ageBuckets['36-55']++;
//     else ageBuckets['56+']++;
//   });
//   return { summary, stateCounts, ageBuckets };
// }

function computeSummary() {
  const patients = getPatients();

  const deathsByState = {};
  patients.forEach((p) => {
    if (p.status === "Death") {
      deathsByState[p.state] = (deathsByState[p.state] || 0) + 1;
    }
  });
  const topDeaths = Object.entries(deathsByState)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);
  renderDeathsByState(topDeaths);
  
  const summary = { affected: 0, notAffected: 0, cured: 0, death: 0 };
  const stateCounts = {};
  const ageBuckets = { "0-17": 0, "18-35": 0, "36-55": 0, "56+": 0 };

  patients.forEach((p) => {
    if (p.status === "Affected") summary.affected++;
    else if (p.status === "Death") summary.death++;
    else if (p.status === "Cured") summary.cured++;
    else summary.notAffected++;

    // Map counts (affected + cured)
    if (p.status === "Affected" || p.status === "Cured") {
      stateCounts[p.state] = (stateCounts[p.state] || 0) + 1;
    }

    const age = Number(p.age) || 0;
    if (age <= 17) ageBuckets["0-17"]++;
    else if (age <= 35) ageBuckets["18-35"]++;
    else if (age <= 55) ageBuckets["36-55"]++;
    else ageBuckets["56+"]++;
  });
  return { summary, stateCounts, ageBuckets };
}

function DashboardView() {
  const { summary } = computeSummary();
  return `
    <div class="header-bar">
      <div class="fw-semibold">Dashboard</div>
      <div class="text-secondary small">Real-time from local dataset</div>
    </div>
    <div class="container-fluid py-3">
      <div class="row g-3">
        <div class="col-md-4">
          <div class="card-glass p-3">
            <div id="pie-total" style="height:320px;"></div>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card-glass p-3">
            <div id="india-map" style="height:320px;"></div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="card-glass p-3">
            <div id="age-chart" style="height:280px;"></div>
          </div>
        </div>
        <div>
          <div class="card-glass p-3 mt-3">
            <div class="h6 mb-2">Deaths by State (Top 10)</div>
            <div id="chart-deaths-state" style="height: 320px;"></div>
          </div>

        </div>
      </div>
    </div>
  `;
}

function renderDashboard() {
  const root = document.getElementById("content");

  root.innerHTML = DashboardView();
  const { summary, stateCounts, ageBuckets } = computeSummary();
  renderPie(summary);
  renderIndiaMap(stateCounts);
  renderAgeChart(ageBuckets);
}
