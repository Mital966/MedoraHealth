let fuseInstance = null;

function PatientListView(){
  return `
  <div class="header-bar">
    <div class="fw-semibold">Patient List</div>
    <div class="d-flex gap-2">
      <input id="search" class="form-control form-control-sm" placeholder="Search name or phone">
      <a class="btn btn-sm btn-accent" href="#add-patient">Add Patient</a>
    </div>
  </div>

  <div class="container-fluid py-3">
    <div class="card-glass p-0">
      <div class="table-wrap">
        <table class="table table-hover align-middle mb-0 table-modern">
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone</th>
              <th>Age</th>
              <th>Gender</th>
              <th>State</th>
              <th>Status</th>
              <th>Updated</th>
            </tr>
          </thead>
          <tbody id="patient-rows"></tbody>
        </table>
      </div>
    </div>
  </div>
  ${PatientModal()}
  `;
}

function statusBadge(s){
  const m = {
  'Affected':'affected',
  'Not Affected':'not-affected',
  'Cured':'cured',
  'Death':'death'
}[s] || 'not-affected';
  return `<span class="badge badge-status ${m}">${s}</span>`;
}

function renderRows(list){
  const tbody = document.getElementById('patient-rows');
  tbody.innerHTML = list.map(p => `
    <tr>
      <td class="d-flex align-items-center gap-2">
        <img src="${p.photo || 'img/default-user.png'}" width="32" height="32" class="rounded-circle border border-secondary" alt="photo">
        <button class="btn btn-link p-0 link" onclick="openPatientModal('${p.id}')">${p.name}</button>
      </td>
      <td>${p.phone}</td>
      <td>${p.age}</td>
      <td>${p.gender}</td>
      <td>${p.state}</td>
      <td>
        <select class="form-select form-select-sm w-auto"
                onchange="updatePatient('${p.id}',{status:this.value}); renderPatients(); renderDashboard();">
          <option ${p.status==='Not Affected'?'selected':''}>Not Affected</option>
          <option ${p.status==='Affected'?'selected':''}>Affected</option>
          <option ${p.status==='Cured'?'selected':''}>Cured</option>
          <option ${p.status==='Death'?'selected':''}>Death</option>
        </select>
      </td>
      <td><span class="cell-muted">${new Date(p.updatedAt).toLocaleString()}</span></td>
    </tr>
  `).join('');
}

function renderPatients(){
  const root = document.getElementById('content');
  root.innerHTML = PatientListView();
  const list = getPatients();
  renderRows(list);

  attachPatientModalHandlers();

  // Fuse search
  fuseInstance = new Fuse(list, { keys:['name','phone'], threshold:0.4 });
  const input = document.getElementById('search');
  input.addEventListener('input', (e) => {
    const q = e.target.value.trim();
    if(!q){ renderRows(list); return; }
    const res = fuseInstance.search(q).map(r=>r.item);
    renderRows(res);
  });
}
