// Storage & seed
const DB_KEYS = {
  PATIENTS: 'medora:patients',
  USERS: 'medora:users',
  SESSION: 'medora:session'
};

const STATES = [
  "--select--", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh",
  "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland",
  "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Delhi", "Jammu and Kashmir", "Ladakh", "Puducherry", "Chandigarh"
];

function lsGet(key, fallback = null) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch (e) { return fallback; }
}
function lsSet(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

function seedIfEmpty() {
  if (!lsGet(DB_KEYS.USERS)) {
    lsSet(DB_KEYS.USERS, [
      { id: 'u_doc_1', role: 'doctor', name: 'Dr. Mehta', username: 'doctor', password: 'doctor123' },
      { id: 'u_pt_1', role: 'patient', name: 'Aarav Sharma', username: 'aarav', password: '1234', patientId: 'pt_001' }
    ]);
  }
  if (!lsGet(DB_KEYS.PATIENTS)) {
    const now = Date.now();
    lsSet(DB_KEYS.PATIENTS, [
      { id: 'pt_001', name: 'Aarav Sharma', phone: '98xxxxxx12', age: 34, gender: 'Male', state: 'Maharashtra', relative: 'Riya Sharma', status: 'Affected', medication: 'Paracetamol 500mg, Vitamin C, Hydration', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_002', name: 'Neha Verma', phone: '91xxxxxx77', age: 29, gender: 'Female', state: 'Delhi', relative: 'Amit Verma', status: 'Not Affected', medication: '-', createdAt: now - 86400000 * 3, updatedAt: now - 86400000 * 1 },
      { id: 'pt_003', name: 'Sanjay Patel', phone: '97xxxxxx45', age: 52, gender: 'Male', state: 'Gujarat', relative: 'Pooja Patel', status: 'Death', medication: '-', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 7 },
      { id: 'pt_004', name: 'Ananya Rao', phone: '99xxxxxx90', age: 41, gender: 'Female', state: 'Karnataka', relative: 'Rao Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 2 },
      { id: 'pt_005', name: 'Rajesh Kumar', phone: '98xxxxxx23', age: 45, gender: 'Male', state: 'Maharashtra', relative: 'Kumar Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 1 },
      { id: 'pt_006', name: 'Priya Sharma', phone: '97xxxxxx42', age: 34, gender: 'Female', state: 'Delhi', relative: 'Sharma Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 3 },
      { id: 'pt_007', name: 'Vikram Patel', phone: '99xxxxxx81', age: 29, gender: 'Male', state: 'Gujarat', relative: 'Patel Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 2, updatedAt: now - 86400000 * 1 },
      { id: 'pt_008', name: 'Sneha Nair', phone: '95xxxxxx37', age: 38, gender: 'Female', state: 'Kerala', relative: 'Nair Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 2 },
      { id: 'pt_009', name: 'Amit Singh', phone: '96xxxxxx51', age: 50, gender: 'Male', state: 'Uttar Pradesh', relative: 'Singh Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 10, updatedAt: now - 86400000 * 3 },
      { id: 'pt_010', name: 'Meera Iyer', phone: '99xxxxxx33', age: 27, gender: 'Female', state: 'Tamil Nadu', relative: 'Iyer Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 2 },
      { id: 'pt_011', name: 'Arjun Deshmukh', phone: '98xxxxxx76', age: 31, gender: 'Male', state: 'Maharashtra', relative: 'Deshmukh Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 3, updatedAt: now - 86400000 * 1 },
      { id: 'pt_012', name: 'Ritika Joshi', phone: '97xxxxxx09', age: 36, gender: 'Female', state: 'Rajasthan', relative: 'Joshi Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 4 },
      { id: 'pt_013', name: 'Naveen Gupta', phone: '99xxxxxx12', age: 42, gender: 'Male', state: 'Delhi', relative: 'Gupta Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 2 },
      { id: 'pt_014', name: 'Anjali Das', phone: '95xxxxxx44', age: 33, gender: 'Female', state: 'West Bengal', relative: 'Das Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 3 },
      { id: 'pt_015', name: 'Suresh Reddy', phone: '96xxxxxx27', age: 48, gender: 'Male', state: 'Telangana', relative: 'Reddy Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 9, updatedAt: now - 86400000 * 4 },
      { id: 'pt_016', name: 'Divya Kapoor', phone: '97xxxxxx66', age: 30, gender: 'Female', state: 'Punjab', relative: 'Kapoor Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 1 },
      { id: 'pt_017', name: 'Manoj Mehta', phone: '99xxxxxx22', age: 40, gender: 'Male', state: 'Gujarat', relative: 'Mehta Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 3 },
      { id: 'pt_018', name: 'Pooja Chatterjee', phone: '98xxxxxx88', age: 28, gender: 'Female', state: 'West Bengal', relative: 'Chatterjee Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 3, updatedAt: now - 86400000 * 2 },
      { id: 'pt_019', name: 'Rohit Bansal', phone: '97xxxxxx11', age: 37, gender: 'Male', state: 'Haryana', relative: 'Bansal Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 10, updatedAt: now - 86400000 * 1 },
      { id: 'pt_020', name: 'Kavita Pillai', phone: '95xxxxxx30', age: 41, gender: 'Female', state: 'Kerala', relative: 'Pillai Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 4 },
      { id: 'pt_021', name: 'Ramesh Yadav', phone: '96xxxxxx02', age: 35, gender: 'Male', state: 'Uttar Pradesh', relative: 'Yadav Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 2 },
      { id: 'pt_022', name: 'Aishwarya Ghosh', phone: '97xxxxxx13', age: 26, gender: 'Female', state: 'West Bengal', relative: 'Ghosh Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 2 },
      { id: 'pt_023', name: 'Deepak Verma', phone: '99xxxxxx87', age: 39, gender: 'Male', state: 'Madhya Pradesh', relative: 'Verma Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 1 },
      { id: 'pt_024', name: 'Nisha Menon', phone: '98xxxxxx26', age: 44, gender: 'Female', state: 'Kerala', relative: 'Menon Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 3 },
      { id: 'pt_025', name: 'Aditya Jain', phone: '97xxxxxx08', age: 32, gender: 'Male', state: 'Rajasthan', relative: 'Jain Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 2 },
      { id: 'pt_026', name: 'Tanya Bhattacharya', phone: '99xxxxxx77', age: 29, gender: 'Female', state: 'West Bengal', relative: 'Bhattacharya Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 3 },
      { id: 'pt_027', name: 'Kiran Rao', phone: '95xxxxxx92', age: 46, gender: 'Male', state: 'Karnataka', relative: 'Rao Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 9, updatedAt: now - 86400000 * 4 },
      { id: 'pt_028', name: 'Shreya Mukherjee', phone: '96xxxxxx59', age: 33, gender: 'Female', state: 'West Bengal', relative: 'Mukherjee Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_029', name: 'Harish Kumar', phone: '97xxxxxx04', age: 38, gender: 'Male', state: 'Tamil Nadu', relative: 'Kumar Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 2 },
      { id: 'pt_030', name: 'Lakshmi Reddy', phone: '99xxxxxx90', age: 27, gender: 'Female', state: 'Telangana', relative: 'Reddy Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 3 },
      { id: 'pt_031', name: 'Sunil Sharma', phone: '98xxxxxx43', age: 43, gender: 'Male', state: 'Delhi', relative: 'Sharma Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 10, updatedAt: now - 86400000 * 5 },
      { id: 'pt_032', name: 'Rekha Pillai', phone: '95xxxxxx12', age: 40, gender: 'Female', state: 'Kerala', relative: 'Pillai Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 1 },
      { id: 'pt_033', name: 'Vivek Tiwari', phone: '96xxxxxx68', age: 37, gender: 'Male', state: 'Uttar Pradesh', relative: 'Tiwari Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_034', name: 'Monica Dasgupta', phone: '97xxxxxx31', age: 35, gender: 'Female', state: 'West Bengal', relative: 'Dasgupta Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 3 },
      { id: 'pt_035', name: 'Sanjay Patil', phone: '99xxxxxx52', age: 42, gender: 'Male', state: 'Maharashtra', relative: 'Patil Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 2 },
      { id: 'pt_036', name: 'Neha Raina', phone: '98xxxxxx73', age: 31, gender: 'Female', state: 'Jammu & Kashmir', relative: 'Raina Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 4 },
      { id: 'pt_037', name: 'Arvind Mishra', phone: '97xxxxxx05', age: 39, gender: 'Male', state: 'Madhya Pradesh', relative: 'Mishra Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_038', name: 'Rupal Shah', phone: '99xxxxxx38', age: 29, gender: 'Female', state: 'Gujarat', relative: 'Shah Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 2 },
      { id: 'pt_039', name: 'Nitin Malhotra', phone: '95xxxxxx01', age: 34, gender: 'Male', state: 'Punjab', relative: 'Malhotra Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 1 },
      { id: 'pt_040', name: 'Shalini Menon', phone: '96xxxxxx84', age: 45, gender: 'Female', state: 'Kerala', relative: 'Menon Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 3 },
      { id: 'pt_041', name: 'Ashok Verma', phone: '97xxxxxx39', age: 50, gender: 'Male', state: 'Delhi', relative: 'Verma Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 9, updatedAt: now - 86400000 * 4 },
      { id: 'pt_042', name: 'Pallavi Raut', phone: '99xxxxxx99', age: 32, gender: 'Female', state: 'Maharashtra', relative: 'Raut Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_043', name: 'Tarun Aggarwal', phone: '98xxxxxx06', age: 37, gender: 'Male', state: 'Haryana', relative: 'Aggarwal Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 2 },
      { id: 'pt_044', name: 'Sakshi Nanda', phone: '97xxxxxx50', age: 28, gender: 'Female', state: 'Punjab', relative: 'Nanda Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 1 },
      { id: 'pt_045', name: 'Ganesh Iyer', phone: '99xxxxxx79', age: 46, gender: 'Male', state: 'Tamil Nadu', relative: 'Iyer Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 3 },
      { id: 'pt_046', name: 'Nikita Basu', phone: '95xxxxxx48', age: 30, gender: 'Female', state: 'West Bengal', relative: 'Basu Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 3 },
      { id: 'pt_047', name: 'Ravi Chauhan', phone: '96xxxxxx22', age: 40, gender: 'Male', state: 'Uttar Pradesh', relative: 'Chauhan Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 2 },
      { id: 'pt_048', name: 'Ishita Rao', phone: '97xxxxxx89', age: 27, gender: 'Female', state: 'Karnataka', relative: 'Rao Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 3, updatedAt: now - 86400000 * 1 },
      { id: 'pt_049', name: 'Kunal Sinha', phone: '99xxxxxx14', age: 35, gender: 'Male', state: 'West Bengal', relative: 'Sinha Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 3 },
      { id: 'pt_050', name: 'Ankita Reddy', phone: '98xxxxxx62', age: 38, gender: 'Female', state: 'Telangana', relative: 'Reddy Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Steam inhalation', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_051', name: 'Harsha Bhatt', phone: '97xxxxxx71', age: 31, gender: 'Male', state: 'Gujarat', relative: 'Bhatt Sr.', status: 'Recovered', medication: 'Doxycycline 100mg', createdAt: now - 86400000 * 8, updatedAt: now - 86400000 * 3 },
      { id: 'pt_052', name: 'Preeti Nair', phone: '99xxxxxx60', age: 42, gender: 'Female', state: 'Kerala', relative: 'Nair Sr.', status: 'Affected', medication: 'Azithromycin 500mg, Vitamin C', createdAt: now - 86400000 * 4, updatedAt: now - 86400000 * 2 },
      { id: 'pt_053', name: 'Abhishek Sharma', phone: '95xxxxxx91', age: 36, gender: 'Male', state: 'Delhi', relative: 'Sharma Sr.', status: 'Recovered', medication: 'Paracetamol 500mg', createdAt: now - 86400000 * 7, updatedAt: now - 86400000 * 3 },
      { id: 'pt_054', name: 'Ritu Khanna', phone: '96xxxxxx07', age: 34, gender: 'Female', state: 'Punjab', relative: 'Khanna Sr.', status: 'Affected', medication: 'Azithromycin 500mg', createdAt: now - 86400000 * 5, updatedAt: now - 86400000 * 2 },
      { id: 'pt_055', name: 'Gaurav Singh', phone: '97xxxxxx25', age: 39, gender: 'Male', state: 'Uttar Pradesh', relative: 'Singh Sr.', status: 'Recovered', medication: 'Dolo 650mg', createdAt: now - 86400000 * 6, updatedAt: now - 86400000 * 3 }
    ]);
  }
}
seedIfEmpty();

// Auth
function login(username, password) {
  const users = lsGet(DB_KEYS.USERS, []);
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    lsSet(DB_KEYS.SESSION, { userId: user.id, role: user.role, patientId: user.patientId || null });
    return { ok: true, user };
  }
  return { ok: false };
}
function logout() {
  localStorage.removeItem(DB_KEYS.SESSION);
  location.hash = '#login';
  renderApp();
}
function getSession() {
  return lsGet(DB_KEYS.SESSION);
}

function uid(prefix = 'id') {
  return prefix + '_' + Math.random().toString(36).slice(2, 8);
}

// Patients CRUD
function getPatients() { return lsGet(DB_KEYS.PATIENTS, []); }
function setPatients(list) { lsSet(DB_KEYS.PATIENTS, list); }
// function addPatient(p){
//   const list = getPatients();
//   list.push({ ...p, id: uid('pt'), createdAt: Date.now(), updatedAt: Date.now() });
//   setPatients(list); return p;
// }

function addPatient(p) {
  const list = getPatients();
  const newId = uid('pt');
  const patient = { ...p, id: newId, createdAt: Date.now(), updatedAt: Date.now() };
  list.push(patient);
  setPatients(list);

  // Create a linked patient login
  const users = lsGet(DB_KEYS.USERS, []);
  const username = p.name.toLowerCase().slice(-6);
  const password = String(p.phone).slice(-4);
  users.push({
    id: uid('u_pt'),
    role: 'patient',
    name: p.name,
    username,
    password,
    patientId: newId
  });
  lsSet(DB_KEYS.USERS, users);

  showToast(`New patient added!\\nUsername: ${username}\\nPassword: ${password}`,'success');

  return patient;
}
function updatePatient(id, patch) {
  const list = getPatients().map(p => p.id === id ? { ...p, ...patch, updatedAt: Date.now() } : p);
  setPatients(list);
}
function getPatientById(id) { return getPatients().find(p => p.id === id); }

// Export/Import helpers
function exportJSON() {
  const data = {
    patients: getPatients(),
    users: lsGet(DB_KEYS.USERS, [])
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'medora-data.json';
  a.click(); URL.revokeObjectURL(url);
}
function importJSON(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(reader.result);
      if (obj.patients) lsSet(DB_KEYS.PATIENTS, obj.patients);
      if (obj.users) lsSet(DB_KEYS.USERS, obj.users);
      showToast('Import successful. Reloading...','success');
      location.reload();
    } catch (e) { showToast('Invalid file','error'); }
  };
  reader.readAsText(file);
}

function toBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
}

function exportCSV(){
  const rows = getPatients();

  // Define the columns/order you want in Excel:
  const headers = [
    "id","name","phone","age","gender","state","relative",
    "status","medication","createdAt","updatedAt"
  ];

  // Escape cells for CSV
  const esc = (v) => {
    if (v === null || v === undefined) return "";
    v = String(v);
    if (v.includes('"') || v.includes(',') || v.includes('\n')) {
      return '"' + v.replace(/"/g,'""') + '"';
    }
    return v;
  };

  const lines = [];
  lines.push(headers.join(",")); // header row
  for (const r of rows){
    const line = headers.map(h => esc(r[h]));
    lines.push(line.join(","));
  }

  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "medora-patients.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function importCSV(file){
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const text = reader.result;
      const rows = parseCSV(text); // array of objects
      if (!rows.length) return alert("No rows found in CSV.");

      // Normalize keys and add rows
      const existing = getPatients();
      const beforeLen = existing.length;

      rows.forEach(obj => {
        // Map/clean fields
        const p = {
          id: obj.id && String(obj.id).trim() ? String(obj.id).trim() : uid('pt'),
          name: (obj.name || "").trim(),
          phone: (obj.phone || "").trim(),
          age: Number(obj.age || 0),
          gender: (obj.gender || "Other").trim(),
          state: (obj.state || "").trim(),
          relative: (obj.relative || "").trim(),
          status: (obj.status || "Not Affected").trim(),
          medication: (obj.medication || "").trim(),
          createdAt: obj.createdAt ? Number(obj.createdAt) : Date.now(),
          updatedAt: Date.now(),
          // optional photo column support if present
          photo: obj.photo ? String(obj.photo) : (obj.image || "")
        };

        // If same id already exists, update; else push
        const idx = existing.findIndex(x => x.id === p.id);
        if (idx >= 0) existing[idx] = { ...existing[idx], ...p };
        else existing.push(p);
      });

      setPatients(existing);
      showToast(`CSV imported. ${existing.length - beforeLen >= 0 ? (existing.length - beforeLen) : 0} new/updated records.`,'success');
      // re-render if you're on these screens
      if (location.hash === '#patients') renderPatients();
      if (location.hash === '#dashboard') renderDashboard();
    }catch(e){
      console.error(e);
      showToast('CSV import failed. Please check the file format.','error');
    }
  };
  reader.readAsText(file);
}

// Simple CSV -> objects (assumes first row is header)
function parseCSV(text){
  const lines = text.replace(/\r/g,'').split('\n').filter(Boolean);
  if (!lines.length) return [];

  const headers = splitCSVLine(lines[0]).map(h => h.trim());
  const out = [];
  for (let i=1; i<lines.length; i++){
    const cols = splitCSVLine(lines[i]);
    const obj = {};
    headers.forEach((h, idx) => obj[h] = cols[idx] ?? "");
    out.push(obj);
  }
  return out;
}

// Handle commas and quotes correctly in a CSV line
function splitCSVLine(line){
  const res = [];
  let cur = '';
  let inQuotes = false;

  for (let i=0; i<line.length; i++){
    const ch = line[i];
    if (inQuotes){
      if (ch === '"'){
        if (line[i+1] === '"'){ cur += '"'; i++; } // escaped quote
        else { inQuotes = false; }
      } else {
        cur += ch;
      }
    } else {
      if (ch === ','){ res.push(cur); cur=''; }
      else if (ch === '"'){ inQuotes = true; }
      else { cur += ch; }
    }
  }
  res.push(cur);
  return res;
}

function handleImageError(imgElement) {
  imgElement.onerror = null; // prevent infinite loop
  imgElement.src = '';
  imgElement.style.background = '#2d3748';
  imgElement.style.display = 'inline-flex';
  imgElement.style.alignItems = 'center';
  imgElement.style.justifyContent = 'center';
  imgElement.style.color = '#aaa';
  imgElement.style.fontSize = '13px';
  imgElement.style.textAlign = 'center';
  imgElement.style.width = imgElement.width + 'px';
  imgElement.style.height = imgElement.height + 'px';
  imgElement.style.borderRadius = '50%';
  imgElement.innerText = '';
  
  // Add small “No image” overlay
  // const span = document.createElement('div');
  // span.textContent = 'Image Preview';
  // span.style.color = '#ccc';
  // span.style.fontSize = '12px';
  // span.style.marginTop = '4px';
  // imgElement.parentNode.appendChild(span);
}
