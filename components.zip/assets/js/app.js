// Basic SPA shell + routing
function AppShell(content) {
  const session = getSession();
  const role = session?.role || null;
  return `
  <div class="d-flex">
    ${role ? Sidebar(role) : ""}
    <div class="flex-grow-1" id="content">
      ${content}
    </div>
  </div>`;
}

function LoginView() {
  return `
  <div class="container py-5" style="max-width: 520px;">
    <div class="card-glass p-4">
      <div class="h4 mb-3 text-center">Medora Health – COVID</div>
      <div class="text-secondary text-center mb-4">Login as Doctor or Patient</div>
      <form id="login-form" class="row g-3">
        <div class="col-12">
          <label class="form-label">Username</label>
          <input class="form-control" id="l-username" placeholder="doctor / aarav" required>
        </div>
        <div class="col-12">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" id="l-password" placeholder="doctor123 / 1234" required>
        </div>
        <div class="col-12 d-grid">
          <button class="btn btn-accent">Login</button>
        </div>
      </form>
      <div class="small text-secondary mt-3">Demo accounts: <code>doctor/doctor123</code>, <code>aarav/1234</code></div>
    </div>
  </div>`;
}

function renderApp() {
  const session = getSession();
  if (!session) {
    renderLogin(); // If no session, go back to login
    return;
  }

  // Build main layout
  document.getElementById('app').innerHTML = AppShell(Sidebar(session.role));

  // Load initial route
  route();
}


function renderLogin() {
  // Directly render login page without sidebar wrapper
  document.getElementById('app').innerHTML = `
  <div class="login-wrapper d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    ${LoginView()}
  </div>`;
  
  // Attach login logic
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const u = document.getElementById('l-username').value.trim();
    const p = document.getElementById('l-password').value.trim();

    showLoader('Signing you in…');
    const res = login(u, p);
    if (res.ok) {
      hideLoader();
      showToast('Login Success', 'success');
      location.hash = res.user.role === 'doctor' ? '#dashboard' : '#profile';
      renderApp();
    } else {
      hideLoader();
      showToast('Invalid credentials', 'error');
    }
  });
}



function route(){
  const session = getSession();
  if(!session){ renderLogin(); return; }

  showLoader('Loading page…');                  // 🔹 show at start
  try {
    const hash = location.hash || (session.role==='doctor' ? '#dashboard' : '#profile');
    if(hash==='#logout'){ logout(); return; }

    document.getElementById('app').innerHTML = AppShell('<div class="p-4">Loading…</div>');
    highlightActive();

    if(session.role==='doctor'){
      if(hash==='#dashboard') renderDashboard();
      else if(hash==='#patients') renderPatients();
      else if(hash==='#add-patient') renderAddPatient();
      else renderDashboard();
    } else {
      if(hash==='#profile') renderProfile();
      else if(hash==='#medication') renderMedication();
      else renderProfile();
    }
    highlightActive();
  } finally {
    // Slight timeout makes the transition feel smoother; remove if you want instant
    setTimeout(hideLoader, 200);               // 🔹 hide at end
  }
}

function ensureToastContainer() {
  let el = document.getElementById('mh-toast-container');
  if (!el) {
    el = document.createElement('div');
    el.id = 'mh-toast-container';
    // inline fallback so it works even without CSS
    el.style.position = 'fixed';
    el.style.top = '20px';
    el.style.right = '24px';
    el.style.zIndex = '10050'; // above your #loader-overlay (9999)
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.gap = '10px';
    document.body.appendChild(el);
  }
  return el;
}

function showToast(message, type = 'info') {
  const container = ensureToastContainer();

  const toast = document.createElement('div');
  toast.className = `mh-toast mh-${type}`;
  toast.textContent = message;

  // fallback inline styles so it works even without CSS file
  toast.style.minWidth = '240px';
  toast.style.maxWidth = '340px';
  toast.style.padding = '12px 16px';
  toast.style.borderRadius = '8px';
  toast.style.background = '#ffffff';
  toast.style.color = '#0a111f';
  toast.style.fontSize = '14px';
  toast.style.fontWeight = '500';
  toast.style.boxShadow = '0 4px 16px rgba(0,0,0,0.15)';
  toast.style.opacity = '0';
  toast.style.transform = 'translateX(20px)';
  toast.style.transition = 'all .3s ease';

  const borderColors = { success: '#22c55e', error: '#e55353', info: '#20c997' };
  toast.style.borderLeft = `4px solid ${borderColors[type] || borderColors.info}`;

  container.appendChild(toast);

  // animate in
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  // auto remove after 3.5s
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}


// function showToast(message, type = 'info') {
//   const container = document.getElementById('toast-container');
//   const toast = document.createElement('div');
//   toast.className = `toast ${type}`;
//   toast.textContent = message;

//   container.appendChild(toast);

//   // remove automatically after animation ends
//   setTimeout(() => toast.remove(), 3500);
// }



window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', ()=>{
  const session = getSession();
  if(session) renderApp();
  else renderLogin();
});

